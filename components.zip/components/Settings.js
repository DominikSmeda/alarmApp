


export const ip = "192.168.1.20"

export const port = "3000"
