import React, { Component } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import zdj from './user.jpg'
class EditUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };

    }

    render() {
        return (
            <View style={styles.container}>
                <Image
                    style={{ width: 100, height: 100 }}
                    source={zdj}
                />

                <Text>{this.props.navigation.state.params.username}:</Text>
                <Text>{this.props.navigation.state.params.password}</Text>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: "space-around",
        alignItems: 'center',
    }
})

export default EditUser;
